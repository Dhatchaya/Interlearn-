function employePayment(){
    var perClassPayment = document.getElementsByClassName("per-class-pay");
console.log(classCount.length);
var classCount = document.getElementsByClassName("class-count");
console.log("classCount");
var Totalpay = document.getElementsByClassName("total-pay");

 for(var i = 0; i<classCount.length; i++ ){
    var perClassPaymentInt = parseInt(perClassPayment[i]);
    var classCountInt = parseInt(classCount[i]);
    Totalpay.innerHTML = perClassPaymentInt * classCountInt;
 }  











}

